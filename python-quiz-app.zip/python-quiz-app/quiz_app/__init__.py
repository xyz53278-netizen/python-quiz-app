from flask import Flask
from .db import init_db
from .routes import register_routes

def create_app(test_config=None):
    app = Flask(__name__)
    app.config.update(SECRET_KEY="dev-only-change-me", DATABASE="quiz.db")
    if test_config:
        app.config.update(test_config)
    init_db(app)
    register_routes(app)
    return app
