import sqlite3
from pathlib import Path
from flask import current_app, g

def get_db():
    if "db" not in g:
        path = Path(current_app.config["DATABASE"])
        if not path.is_absolute():
            path = Path(current_app.root_path).parent / path
        path.parent.mkdir(parents=True, exist_ok=True)
        g.db = sqlite3.connect(path)
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db(app):
    with app.app_context():
        db = get_db()
        db.executescript("""
        CREATE TABLE IF NOT EXISTS questions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          question TEXT NOT NULL,
          option_a TEXT NOT NULL, option_b TEXT NOT NULL,
          option_c TEXT NOT NULL, option_d TEXT NOT NULL,
          correct_option TEXT NOT NULL CHECK(correct_option IN ('A','B','C','D')),
          explanation TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS quiz_attempts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          player_name TEXT NOT NULL,
          score INTEGER NOT NULL,
          total INTEGER NOT NULL,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """)
        if db.execute("SELECT COUNT(*) FROM questions").fetchone()[0] == 0:
            db.executemany(
                "INSERT INTO questions (question,option_a,option_b,option_c,option_d,correct_option,explanation) VALUES (?,?,?,?,?,?,?)",
                [
                    ("Which keyword defines a function in Python?", "func", "def", "function", "define", "B", "Python uses def to define a function."),
                    ("Which collection stores key-value pairs?", "List", "Tuple", "Dictionary", "Set", "C", "A dictionary stores key-value pairs."),
                    ("Which HTTP method commonly retrieves a resource?", "POST", "GET", "PATCH", "DELETE", "B", "GET is commonly used to retrieve resources."),
                    ("Which SQL command reads rows from a table?", "SELECT", "INSERT", "UPDATE", "DROP", "A", "SELECT retrieves rows."),
                    ("Which Python type represents True or False?", "str", "int", "bool", "float", "C", "bool is Python's Boolean type.")
                ]
            )
        db.commit()
    app.teardown_appcontext(close_db)
