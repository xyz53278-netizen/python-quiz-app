import logging
from flask import jsonify, render_template, request
from .db import get_db

logger = logging.getLogger(__name__)

def register_routes(app):
    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/questions")
    def questions():
        rows = get_db().execute("SELECT id,question,option_a,option_b,option_c,option_d FROM questions ORDER BY id").fetchall()
        return jsonify([{"id": r["id"], "question": r["question"], "options": {"A": r["option_a"], "B": r["option_b"], "C": r["option_c"], "D": r["option_d"]}} for r in rows])

    @app.post("/api/submit")
    def submit():
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "Request body must be a JSON object"}), 400
        name, answers = payload.get("player_name"), payload.get("answers")
        if not isinstance(name, str) or not name.strip() or len(name.strip()) > 80:
            return jsonify({"error": "player_name must be 1–80 characters"}), 400
        if not isinstance(answers, dict):
            return jsonify({"error": "answers must be an object"}), 400
        db = get_db()
        rows = db.execute("SELECT id,correct_option,explanation FROM questions ORDER BY id").fetchall()
        score, results = 0, []
        for row in rows:
            correct = answers.get(str(row["id"]))
            ok = isinstance(correct, str) and correct.upper() == row["correct_option"]
            score += int(ok)
            results.append({"question_id": row["id"], "correct": ok, "correct_option": row["correct_option"], "explanation": row["explanation"]})
        db.execute("INSERT INTO quiz_attempts (player_name,score,total) VALUES (?,?,?)", (name.strip(), score, len(rows)))
        db.commit()
        logger.info("Quiz submitted by %s: %s/%s", name.strip(), score, len(rows))
        return jsonify({"player_name": name.strip(), "score": score, "total": len(rows), "results": results})

    @app.get("/api/leaderboard")
    def leaderboard():
        rows = get_db().execute("SELECT player_name,score,total,created_at FROM quiz_attempts ORDER BY score DESC, created_at ASC LIMIT 10").fetchall()
        return jsonify([dict(row) for row in rows])

    @app.errorhandler(500)
    def internal_error(error):
        logger.exception("Unhandled application error: %s", error)
        return jsonify({"error": "Internal server error"}), 500
