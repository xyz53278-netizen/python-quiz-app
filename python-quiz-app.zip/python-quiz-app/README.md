# 🐍 Python Quiz App

A portfolio-ready multiple-choice quiz application built with Flask and SQLite. Players answer questions, submit their attempt, see their score, and view a leaderboard.

## Features
- Browser-based quiz interface
- REST endpoints for questions, submissions, and leaderboard
- SQLite persistence for questions and quiz attempts
- Input validation and parameterized SQL queries
- Modular structure, exception handling, and logging
- Automated tests using pytest

## Tech Stack
Python · Flask · SQLite · HTML · CSS · JavaScript · Pytest

## Architecture
```text
Browser (HTML/CSS/JavaScript)
          | fetch JSON
          v
Flask routes: /api/questions, /api/submit, /api/leaderboard
          |
          v
SQLite: questions + quiz_attempts
```

## Database Schema

### `questions`
| Column | Type | Description |
|---|---|---|
| id | INTEGER | Primary key |
| question | TEXT | Question text |
| option_a ... option_d | TEXT | Answer choices |
| correct_option | TEXT | A, B, C, or D |
| explanation | TEXT | Explanation for answer |

### `quiz_attempts`
| Column | Type | Description |
|---|---|---|
| id | INTEGER | Primary key |
| player_name | TEXT | Player name |
| score | INTEGER | Correct answers |
| total | INTEGER | Total questions |
| created_at | TEXT | SQLite timestamp |

## Setup
Python 3.10+ recommended.

```bash
python -m venv .venv
```
Windows:
```bash
.venv\Scripts\activate
```
macOS/Linux:
```bash
source .venv/bin/activate
```

Install and run:
```bash
python -m pip install -r requirements.txt
python run.py
```
Open http://127.0.0.1:5000 in your browser.

## API Endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/` | Quiz interface |
| GET | `/api/questions` | List questions without answers |
| POST | `/api/submit` | Score and save an attempt |
| GET | `/api/leaderboard` | Top ten scores |

## Run Tests
```bash
python -m pytest -q
```

## Demo Video Checklist
1. Start the application and open the quiz.
2. Enter a name and answer questions.
3. Submit and show the result.
4. Refresh to demonstrate that the leaderboard is stored in SQLite.
5. Show the code structure and README.
Add your recording link here: **Demo video:** _Add your video URL_

## Deployment
Deploy on a Python-compatible host. Use a production WSGI server (such as Gunicorn) and ensure SQLite has persistent writable storage. Do not expose Flask's development debug server publicly. On hosts with ephemeral filesystems, database records can disappear after restarts.

## Future Improvements
- Admin interface for adding questions
- Categories, difficulty levels, and timers
- User accounts and attempt history
- Responsive UI improvements

## Author
**Kamal Dhaka** — B.Tech Artificial Intelligence & Data Science Student

*Built as a learning and portfolio project.*
