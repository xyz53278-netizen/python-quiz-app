from quiz_app import create_app

def test_questions_submit_and_leaderboard(tmp_path):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.db")})
    client = app.test_client()
    qs = client.get("/api/questions")
    assert qs.status_code == 200
    questions = qs.get_json()
    response = client.post("/api/submit", json={"player_name": "Test Player", "answers": {}})
    assert response.status_code == 200
    assert response.get_json()["total"] == len(questions)
    board = client.get("/api/leaderboard")
    assert board.status_code == 200
    assert board.get_json()[0]["player_name"] == "Test Player"

def test_invalid_submission(tmp_path):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.db")})
    response = app.test_client().post("/api/submit", json={"player_name": "", "answers": []})
    assert response.status_code == 400
